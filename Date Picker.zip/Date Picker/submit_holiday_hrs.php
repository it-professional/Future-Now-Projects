<?php include('../class_db.php');
   	  include('../includes/functions/functions.inc');
	  
	  if(isset($_POST['updatehourform'])){
		  
		  $dbconnect = new db_exchange;
		  $db_holiday_id = '';
		  
		  $storeid = $_POST['store_id'];
		  $empid = $_POST['emp_id'];
		  $hoursdate = $_POST['date'];
		  $opening_hours = $_POST['openinghours'];
		  $closing_hours = $_POST['closinghours'];
		  
		  $select_query = "SELECT holiday_id FROM prime_store_time_holiday WHERE store_id = '$storeid' AND holiday_date = '$hoursdate'";
		  $result = $dbconnect->query($select_query);
		  $rows = mysql_num_rows($dbconnect->num_rows);
		  if($rows > 0){
			  while($row = mysql_fetch_array($result)){
				  $db_holiday_id = $row['holiday_id'];
			  }
		  }else{
			  $insert_query = "INSERT INTO prime_store_time_holiday(store_id,updatedby_eid,holiday_date,Start_Time,End_Time) VALUES('$storeid','$empid','$hoursdate','$opening_hours','$closing_hours')";
		  }
		  
	  }
?>