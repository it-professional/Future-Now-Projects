<script type="text/javascript" src="datepicker/formden.js"></script>
<link rel="stylesheet" href="datepicker/bootstrap-iso.css" />

<?php if(isset($_REQUEST['msg']) && $_REQUEST['msg'] == "success"): ?>
 <div style="color:#18ED58" id="successmsg">Hours added Successfully</div>
 <?php endif; ?>
 
 
<div class="bootstrap-iso">
 <div class="container-fluid">
  <div class="row">
   <div class="col-md-6 col-sm-6 col-xs-12">
    <form action="submit_holiday_hrs.php" class="form-horizontal" method="post">
     
     <div class="form-group ">
      <label class="control-label col-sm-2 requiredField" for="date">Date</label>
      <div class="col-sm-10">
       <div class="input-group">
        <input class="form-control" id="date" name="date" placeholder="MM/DD/YYYY" type="text"/>
       </div>
      </div>
     </div>
     
     <div class="form-group ">
      <label class="control-label col-sm-2 requiredField" for="date">Open Hours</label>
      <div class="col-sm-10 input-group">
       <select class="form-control" name="openinghours">
       	<option value="Closed">Closed</option>
        <option value="07:00 AM">07:00 AM</option>
        <option value="07:30 AM">07:30 AM</option>
        <option value="08:00 AM">08:00 AM</option>
        <option value="08:30 AM">08:30 AM</option>
        <option value="09:00 AM">09:00 AM</option>
        <option value="09:30 AM">09:30 AM</option>
        <option value="10:00 AM">10:00 AM</option>
        <option value="10:30 AM">10:30 AM</option>
        <option value="11:00 AM">11:00 AM</option>
        <option value="11:30 AM">11:30 AM</option>
        <option value="12:00 PM">12:00 PM</option>
        <option value="12:30 PM">12:30 PM</option>
        <option value="01:00 PM">01:00 PM</option>
       </select>
      </div>
     </div>
     
     <div class="form-group ">
      <label class="control-label col-sm-2 requiredField" for="date">Close Hours</label>
      <div class="col-sm-10 input-group">
       <select class="form-control" name="closinghours">
            <option value="Closed">Closed</option>
            <option value="12:00 PM">12:00 PM</option>
            <option value="12:30 PM">12:30 PM</option>
            <option value="01:00 PM">01:00 PM</option>
            <option value="01:30 PM">01:30 PM</option>
            <option value="02:00 PM">02:00 PM</option>
            <option value="02:30 PM">02:30 PM</option>
            <option value="03:00 PM">03:00 PM</option>
            <option value="03:30 PM">03:30 PM</option>
            <option value="04:00 PM">04:00 PM</option>
            <option value="04:30 PM">04:30 PM</option>
            <option value="05:00 PM">05:00 PM</option>
            <option value="05:30 PM">05:30 PM</option>
            <option value="06:00 PM">06:00 PM</option>
            <option value="06:30 PM">06:30 PM</option>
            <option value="07:00 PM">07:00 PM</option>
            <option value="07:30 PM">07:30 PM</option>
            <option value="08:00 PM">08:00 PM</option>
            <option value="08:30 PM">08:30 PM</option>
            <option value="09:00 PM">09:00 PM</option>
            <option value="09:30 PM">09:30 PM</option>
            <option value="10:00 PM">10:00 PM</option>
            <option value="10:30 PM">10:30 PM</option>
            <option value="11:00 PM">11:00 PM</option>
            <option value="11:30 PM">11:30 PM</option>
        </select>
      </div>
     </div>
     
     <div class="form-group">
      <div class="col-sm-10 col-sm-offset-2">
      	<input type="hidden" name="store_id" value="<?php if(isset($_REQUEST['sid'])): echo $_REQUEST['sid']; endif; ?>" >
        <input type="hidden" name="emp_id" value="<?php if(isset($_REQUEST['eid'])): echo $_REQUEST['eid']; endif; ?>" >
       <input type="submit" name="updatehourform" value="Submit">
      </div>
     </div>
     
    </form>
   </div>
  </div>
 </div>
</div>

<script type="text/javascript" src="datepicker/jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="datepicker/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="datepicker/bootstrap-datepicker3.css"/>

<script>
	$(document).ready(function(){
		var date_input=$('input[name="date"]');
		var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
		date_input.datepicker({
			format: 'mm/dd/yyyy',
			container: container,
			todayHighlight: true,
			autoclose: true,
		})
	})
</script>