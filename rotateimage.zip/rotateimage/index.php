<html>
<head>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="http://beneposto.pl/jqueryrotate/js/jQueryRotateCompressed.js"></script>
<!-- http://codehaven.co.uk/rotate-and-save-an-image-using-php/ 
http://jqueryrotate.com/
-->
</head>
<body>

 
<img src="uploads/hassan.png" id="emp_image"/>
<p><button type="button" id="rotate_image" class="btn btn-edit">Rotate Image</button></p>
 
 <?php
 $filename = 'https://myprimeportal.com//sites/default/files/pictures/picture-8180-1470520806
.jpg';
 $file_extension = substr($filename, strrpos($filename, '.')); //file extension
 echo "<br><br>image extension is: ".$file_extension;
 
 ?>
<script>		
$(document).ready(function(){
	var angle = 0;
	$("#rotate_image").click(function(){
		angle += 90;
	    $("#emp_image").rotate(angle);
		
	});	
});
</script>
</body>
</html>