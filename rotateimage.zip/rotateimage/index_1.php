<html>
<head>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="http://beneposto.pl/jqueryrotate/js/jQueryRotateCompressed.js"></script>
<!-- http://codehaven.co.uk/rotate-and-save-an-image-using-php/ -->
</head>
<body>

 
<img id="img_1" src="uploads/hassan.png" />
<br>
<button class="btn" id="img" value="90" eid="1111" type="button">Default button</button>
 
<script>		
 
$(document).ready(function(){ 
var value = 0
    $(document).on('click', '#img', function() {
                alert("Hello");
		var eid = $(this).attr("eid");
			alert(eid);
var passvalue = $(this).attr("value");
value = value+parseFloat(passvalue);
alert(value);
    $("#img_1").rotate({animateTo:value});
                var idno = "test";
                $.ajax({
                         url: "saveimage.php",
                         dataType: "html",
                         type: 'POST',
                         data: "panelid="+idno, //variable with data
                         success: function(data){
                            // $(".test").html(data);
                                // alert(data);
                         }
                });
    });
});
</script>
</body>
</html>