<?php
$degrees = -90;  //change this to be whatever degree of rotation you want
 
header('Content-type: image/png');
 
$filename = 'uploads/hassan.png';  //this is the original file
 
$source = imagecreatefrompng($filename) or notfound();
$rotate = imagerotate($source,$degrees,0);
 
imagepng($rotate,$filename); //save the new image
 
imagedestroy($source); //free up the memory
imagedestroy($rotate);  //free up the memory
 
 
?>