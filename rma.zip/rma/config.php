<?php
/*set connection variables */


$host = "162.144.67.118";
$username = "prime_drpl1";
$password = "Z1BQqeipYI663CS7";
$db_name = "prime_omega"; //database name

//connect to mysql server
$pconn = new mysqli($host, $username, $password, $db_name);

//check if any connection error was encountered
if(mysqli_connect_errno()) {
    echo "Error: Could not connect to database.";
    exit;
}
?>