<?php
define('FPDF_FONTPATH','font/');
require('prime_invoice_class2.php');
include('config.php');

$query = mysqli_query($pconn,'Select DISTINCT licence_plate_num From prime_rma_pdf_invoice where licence_plate_num IS NOT NULL');

if(mysqli_num_rows($query) > 0){
	while($result = mysqli_fetch_row($query)){
		if($result[0]){	
			$pdf = new PRIME_Invoice();
			$pdf->SetFont('Times','',11);
			$pdf->setData($result[0]);

			$pdf->AliasNbPages();
			$pdf->AddPage();

			$pdf->InvoiceHeader();
			
			$pdf->Output('F','licence_invoices/invoice_'.$result[0].'.pdf');
		}
	}
	echo "<b>PDF's Generated for all invoices</b>";
}
?>