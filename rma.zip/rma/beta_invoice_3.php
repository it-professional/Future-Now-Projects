<?php
define('FPDF_FONTPATH','font/');
require('prime_invoice_class.php');
include('config.php');


$query = mysqli_query($pconn,'Select original_invoice_id, imei From prime_rma_pdf_invoice');

$counter=1;

if(mysqli_num_rows($query) > 0){
	while($result = mysqli_fetch_row($query)){
		if($result[0]){			
			$counter++;
			
			
			$pdf = new PRIME_Invoice();
			$pdf->SetFont('Times','',11);
			$pdf->setData($result[0],$result[1]);

			$pdf->AliasNbPages();
			$pdf->AddPage();

			$pdf->InvoiceHeader();
			
			$query_2 = mysqli_query($pconn,"Select original_invoice_id From prime_rma_pdf_invoice WHERE original_invoice_id = '$result[0]'");
			if(mysqli_num_rows($query_2) > 1){
				$imei_no = $result[1];
				$last_no = substr($imei_no,-4);
				$pdf->Output('F','invoices/'.$result[0].'_'.$last_no.'.pdf');
			}
			else{
				$pdf->Output('F','invoices/'.$result[0].'.pdf');
			}
		}
	}
	echo "<b>PDF's Generated for all invoices</b>";
}


/*$pdf = new PRIME_Invoice();
$pdf->SetFont('Times','',11);
$invoice_number = 'AIREAIN13891' ;
$pdf->setData($invoice_number);

$pdf->AliasNbPages();
$pdf->AddPage();

$pdf->InvoiceHeader();
//$pdf->makeInvoice();
$pdf->Output('F','invoices/afgh.pdf');*/
?>