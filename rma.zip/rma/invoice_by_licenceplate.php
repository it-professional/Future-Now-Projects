<?php
define('FPDF_FONTPATH','font/');
require('prime_invoice_class2.php');
include('config.php');

/* lets delete all old files in the folder */
$files = glob('licence_invoices/*'); // get all file names
foreach($files as $file){ // iterate files
  if(is_file($file))
    unlink($file); // delete file
}
/* end of deleting all files in folder */

$query = mysqli_query($pconn,'Select DISTINCT licence_plate_num From prime_rma_pdf_invoice');

if(mysqli_num_rows($query) > 0){
	while($result = mysqli_fetch_row($query)){
		if($result[0]){	
			$pdf = new PRIME_Invoice();
			$pdf->SetFont('Times','',11);
			$pdf->setData($result[0]);

			$pdf->AliasNbPages();
			$pdf->AddPage();

			$pdf->InvoiceHeader();
			
			$pdf->Output('F','licence_invoices/invoice_'.trim($result[0]).'.pdf');
		}
	}
	
	$ftp_server = "162.144.67.118";
	$ftp_conn = ftp_connect($ftp_server) or die("Could not connect to $ftp_server");
	$login = ftp_login($ftp_conn, 'new_rma@myprimeportal.com', 'Prime2015@!');
	ftp_pasv($ftp_conn, true);
	
	$files = glob('licence_invoices/*'); // get all file names
	foreach($files as $file){ // iterate files
	  if(is_file($file)){
		
		$file_data = explode('/',$file);
		  if(isset($file_data[1])){
			  ftp_put($ftp_conn, '/'.$file_data[1], $file, FTP_BINARY);
		  }else{
			  ftp_put($ftp_conn, '/home/myprimeportal/public_html/sites/default/files/new_rma/'.$file, $file, FTP_BINARY);
		  }
	  }
	}
		
	$headers = "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
	$headers .= "From: portal@myprimeportal.com";
	
	$to = 'AHazoor@tfntech.com';
	$subject = "RMA PDF's Generated for all invoices";
	$body = "RMA PDF's Generated for all invoices";
	
	mail($to,$subject,$body,$headers);
	
	echo "<b>PDF's Generated for all invoices</b>";
}
?>