<?php
require('fpdf.php');
//define('EURO', chr(128) );
//define('EURO_VAL', 6.55957 );

class PRIME_Invoice extends FPDF
{

public $invoiceid;
public $imeino;

public $host = "162.144.67.118";
public $username = "prime_drpl1";
public $password = "Z1BQqeipYI663CS7";
public $db_name = "prime_omega"; //database name

public $header_flag = 1;
				
public function setData($invoice_id){
    $this->invoiceid = $invoice_id;
}

/*
        function PRIME_Invoice($invoice_number)
        {
            $this->invoiceid = $invoice_number;

        }
*/
		
// Page header
function Header()
{
	// Logo
	$this->Image('image/rq4logo.jpg',10,10,60);
	// Arial bold 15
	$this->SetFont('Arial','B',21);
	// Move to the right
	$this->Cell(150);
	// Title

	if($this->header_flag == 2)
	{
		$this->Cell(30,10,'Return',0,0,'C');
	}else{
		$this->Cell(30,10,'Sale',0,0,'C');
	}
	
}

function InvoiceHeader()
{
	// Logo
//	CHELSIN6259
				$find_records = $counter = 1;
				$pconn = new mysqli($this->host, $this->username, $this->password, $this->db_name);	
				$ss1 = "select * from prime_rma_pdf_invoice where licence_plate_num ='$this->invoiceid'";
				
					if ($result = $pconn->query($ss1)) {
							$find_records = mysqli_num_rows($result); 
							while($obj = $result->fetch_object()){ 
								
								$this->Ln(10);

								$this->Cell(150);	
								$this->Cell(30,10,'Invoice: '.$obj->original_invoice_id,0,0,'C');
								$this->Ln(10);

								$header = array($obj->location, '','');
								$header2 = array($obj->address,'Tendered On: ',$obj->sales_date);
								$header3 = array($obj->Location_CityStateCountry,'Sales Person: ',$obj->employee);
								$header4 = array('','Tendered By',$obj->employee);
								$header5 = array('','Tendered At:',$obj->location);
								
								// Column widths
								$w = array(120,150,90);
								$t = array(120, 40, 25);
								
								// Header
								for($i=0;$i<count($header);$i++)
											$this->Cell($w[$i],7,$header[$i],0,0);
										$this->Ln(5);
										for($i=0;$i<count($header2);$i++)
											$this->Cell($t[$i],7,$header2[$i],0,0);
										$this->Ln(5);										
										for($i=0;$i<count($header3);$i++)
											$this->Cell($t[$i],7,$header3[$i],0,0);
										$this->Ln(5);										
										for($i=0;$i<count($header4);$i++)
											$this->Cell($t[$i],7,$header4[$i],0,0);
										$this->Ln(5);
										for($i=0;$i<count($header5);$i++)
											$this->Cell($t[$i],7,$header5[$i],0,0);
										//$this->Ln();
								$this->Ln(10);
								
								$this->Cell(10,5,'Bill To:',0,1);
								$this->Cell(20);$this->Cell(0,5,$obj->customer,0,1);
								$this->Cell(20);$this->Cell(0,5,$obj->address,0,1);
								$this->Cell(20);$this->Cell(0,5,$obj->customer_phone,0,1);		


								$this->Ln(10);
								$header = array('Product SKU', 'Product Name', 'Serial #', 'Qty', 'List Price', 'Disc %', 'Total Disc', 'Your Total');
								// Column widths
								//$w = array(30, 45, 25, 15,20,20,20,20);
								$w = array(34, 41, 30, 10,20,20,20,20);
								// Header
								for($i=0;$i<count($header);$i++){
									if($i>2){
										$this->Cell($w[$i],7,$header[$i],0,0,'C');
									}else{
										$this->Cell($w[$i],7,$header[$i],0,0);
									}
								}
								$this->Ln();
								$this->Cell(array_sum($w),0,'','T');
								$this->Ln();
								
								
								$this->Cell($w[0],6,$obj->product_sku,0,0);
								//$this->Cell($w[1],6,$obj->phone_description,0,0);
								$multi_cell_desc = 0;
								if(isset($obj->phone_description)){
									$desc_length = strlen($obj->phone_description);	
								}else{
									$desc_length = 0;
								}
								
								if($desc_length > 20){
									$start_x=$this->GetX();
									$start_y=$this->GetY();
									$this->MultiCell($w[1],4,$obj->phone_description,0,'L');
									$this->SetXY($start_x+$w[1],$start_y);
									$multi_cell_desc = 1;
								}else{
									//$this->SetMargins('','',10);
									$this->Cell($w[1],6,$obj->phone_description,0,0);
								}
								
								$this->Cell($w[2],6,$obj->imei,0,0,'C');
								$this->Cell($w[3],6,1,0,0,'C');
								$this->Cell($w[4],6,'$'.number_format($obj->unit_cost,2),0,0,'C');
								$this->Cell($w[5],6,number_format(0,2),0,0,'C');
								$this->Cell($w[6],6,number_format(0,2),0,0,'C');
								$this->Cell($w[6],6,'$'.number_format($obj->unit_cost,2),0,0,'C');
								$this->Ln();
								if($multi_cell_desc == 1){
									$this->Ln();
								}
								
								
								$this->Cell($w[0],6,$obj->rateplan_sku,0,0);
								//$this->Cell($w[1],6,$obj->phone_description,0,0);
								$multi_cell_desc = 0;
								if(isset($obj->rateplan)){
									$desc_length = strlen($obj->rateplan);	
								}else{
									$desc_length = 0;
								}
								
								if($desc_length > 20){
									$start_x=$this->GetX();
									$start_y=$this->GetY();
									$this->MultiCell($w[1],4,$obj->rateplan,0,'L');
									$this->SetXY($start_x+$w[1],$start_y);
									$multi_cell_desc = 1;
								}else{
									//$this->SetMargins('','',10);
									$this->Cell($w[1],6,$obj->rateplan,0,0);
								}
								
								$this->Cell($w[2],6,'',0,0,'C');
								$this->Cell($w[3],6,1,0,0,'C');
								$this->Cell($w[4],6,0,0,0,'C');
								$this->Cell($w[5],6,0,0,0,'C');
								$this->Cell($w[6],6,0,0,0,'C');
								$this->Cell($w[6],6,0,0,0,'C');
								$this->Ln();
								if($multi_cell_desc == 1){
									$this->Ln();
								}
									
								$this->Cell(array_sum($w),0,'','T');
								$this->Ln(3);
  
								$this->SetFont('Times','B',10);
								$this->Cell($w[0],6,'Payment:','B',0);
								$this->SetFont('Times','',10);
								$this->Cell($w[1],6,'',0,0);
								$this->Cell($w[2],6,'',0,0,'C');
								$this->Cell($w[3],6,'',0,0,'C');
								$this->Cell($w[4],6,'','C');
								$this->Cell($w[5],6,'Subtotal','C');
								$this->Cell($w[6],6,'',0,0,'C');
								$this->Cell($w[6],6,'$'.number_format($obj->unit_cost,2),0,0,'C');
								$this->Ln();											
  
								$per = .06;
								$tax = $obj->unit_cost * $per;
								
								$this->SetFont('Times','',11);
								$this->Cell($w[0],6,$obj->payment_type,0,0);
								$this->SetFont('Times','',10);
								$this->Cell($w[1],6,'',0,0);
								$this->Cell($w[2],6,'',0,0,'C');
								$this->Cell($w[3],6,'',0,0,'C');
								$this->Cell($w[4],6,'','C');
								$this->Cell($w[5],6,'Kentucky 6%','B','C');
								$this->Cell($w[6],6,'','B','C');
								$this->Cell($w[6],6,'$'.number_format($tax,2),'B','0','C');
								$this->Ln();
								
								$per = .06;
								$total = $obj->unit_cost + $tax;
								
								$this->SetFont('Times','B',10);
								$this->Cell($w[0],6,'',0,0);
								$this->SetFont('Times','',10);
								$this->Cell($w[1],6,'',0,0);
								$this->Cell($w[2],6,'',0,0,'C');
								$this->Cell($w[3],6,'',0,0,'C');
								$this->Cell($w[4],6,'','C');
								$this->SetFont('Times','B',12);
								$this->Cell($w[5],6,'Total','C');
								$this->Cell($w[6],6,'',0,0,'C');
								$this->Cell($w[6],6,'$'.number_format($total,2),0,0,'C');
								$this->Ln(10);
  
								$this->SetFont('Times','B',10);
								$this->Cell($w[0],6,'Contract Details:','B',0);
								$this->Cell($w[1],6,'','B',0);
								$this->Ln();
  
								$this->SetFont('Times','B',10);
								$this->Cell($w[0],6,'Tracking #',0,0);
								$this->Cell($w[1],6,'Contract #',0,0);
								$this->Ln();
								
								$this->SetFont('Times','',11);
								$this->Cell($w[0],6,$obj->product_sku,0,0);
								$this->Cell($w[1],6,'999999999999',0,0);
									
								$this->Ln();
								
								// Line break
								$this->Ln(20);
  
								$this->header_flag = 2;
								//$this->_endpage();
								$this->AddPage();
  
  
								$this->Ln(10);

								$this->Cell(150);	
								$this->Cell(30,10,'Invoice: '.$obj->return_invoice_id,0,0,'C');
								$this->Ln(10);

								$header = array($obj->location, '','');
								$header2 = array($obj->address,'Tendered On: ',$obj->return_date);
								$header3 = array($obj->customer_phone,'Sales Person: ',$obj->employee);
								$header4 = array('','Tendered By',$obj->employee);
								$header5 = array('','Tendered At:',$obj->location);
								
								// Column widths
								$w = array(120,150,90);
								$t = array(120, 40, 25);
								
								// Header
								for($i=0;$i<count($header);$i++)
											$this->Cell($w[$i],7,$header[$i],0,0);
										$this->Ln(5);
										for($i=0;$i<count($header2);$i++)
											$this->Cell($t[$i],7,$header2[$i],0,0);
										$this->Ln(5);										
										for($i=0;$i<count($header3);$i++)
											$this->Cell($t[$i],7,$header3[$i],0,0);
										$this->Ln(5);										
										for($i=0;$i<count($header4);$i++)
											$this->Cell($t[$i],7,$header4[$i],0,0);
										$this->Ln(5);
										for($i=0;$i<count($header5);$i++)
											$this->Cell($t[$i],7,$header5[$i],0,0);
										//$this->Ln();
							
								$this->Ln(10);
								
								
								$this->Cell(10,5,'Bill To:',0,1);
								$this->Cell(20);$this->Cell(0,5,$obj->customer,0,1);
								$this->Cell(20);$this->Cell(0,5,$obj->address,0,1);
								$this->Cell(20);$this->Cell(0,5,$obj->customer_phone,0,1);		


										$this->Ln(10);
										$header = array('Product SKU', 'Product Name', 'Serial #', 'Qty', 'List Price', 'Disc %', 'Total Disc', 'Your Total');
										// Column widths
										//$w = array(35, 40, 25, 15,20,20,20,20);
										$w = array(34, 41, 30, 10,20,20,20,20);
										// Header
										for($i=0;$i<count($header);$i++){
											if($i>2){
												$this->Cell($w[$i],7,$header[$i],0,0,'C');
											}else{
												$this->Cell($w[$i],7,$header[$i],0,0);
											}
										}	
										$this->Ln();
										$this->Cell(array_sum($w),0,'','T');
										$this->Ln();
										
										
									  $this->Cell($w[0],6,$obj->product_sku,0,0);
									  //$this->Cell($w[1],6,$obj->phone_description,0,0);
									  $multi_cell_desc = 0;
									  if(isset($obj->return_product_name)){
										  $desc_length = strlen($obj->return_product_name);	
									  }else{
										  $desc_length = 0;
									  }
									  
									  if($desc_length > 20){
										  $start_x=$this->GetX();
										  $start_y=$this->GetY();
										  $this->MultiCell($w[1],4,$obj->return_product_name,0,'L');
										  $this->SetXY($start_x+$w[1],$start_y);
										  $multi_cell_desc = 1;
									  }else{
										  //$this->SetMargins('','',10);
										  $this->Cell($w[1],6,$obj->return_product_name,0,0);
									  }
									  
									  $this->Cell($w[2],6,$obj->return_imei,0,0,'C');
									  $this->Cell($w[3],6,-1,0,0,'C');
									  $this->Cell($w[4],6,'-$'.number_format($obj->unit_cost,2),0,0,'C');
									  $this->Cell($w[5],6,number_format(0,2),0,0,'C');
									  $this->Cell($w[6],6,number_format(0,2),0,0,'C');
									  $this->Cell($w[6],6,'-$'.number_format($obj->unit_cost,2),0,0,'C');
									  $this->Ln();
									  if($multi_cell_desc == 1){
										  $this->Ln();
									  }
									  
									  $this->Cell($w[0],6,$obj->rateplan_sku,0,0);
									  //$this->Cell($w[1],6,$obj->phone_description,0,0);
									  $multi_cell_desc = 0;
									  if(isset($obj->rateplan)){
										  $desc_length = strlen($obj->rateplan);	
									  }else{
										  $desc_length = 0;
									  }
									  
									  if($desc_length > 20){
										  $start_x=$this->GetX();
										  $start_y=$this->GetY();
										  $this->MultiCell($w[1],4,$obj->rateplan,0,'L');
										  $this->SetXY($start_x+$w[1],$start_y);
										  $multi_cell_desc = 1;
									  }else{
										  //$this->SetMargins('','',10);
										  $this->Cell($w[1],6,$obj->rateplan,0,0);
									  }
									  
									  $this->Cell($w[2],6,'',0,0,'C');
									  $this->Cell($w[3],6,-1,0,0,'C');
									  $this->Cell($w[4],6,0,0,0,'C');
									  $this->Cell($w[5],6,0,0,0,'C');
									  $this->Cell($w[6],6,0,0,0,'C');
									  $this->Cell($w[6],6,0,0,0,'C');
									  $this->Ln();
									  if($multi_cell_desc == 1){
										  $this->Ln();
									  }
									  
									  $this->Cell(array_sum($w),0,'','T');
									  $this->Ln(3);

									  $this->SetFont('Times','B',10);
									  $this->Cell($w[0],6,'Payment:','B',0);
									  $this->SetFont('Times','',10);
									  $this->Cell($w[1],6,'',0,0);
									  $this->Cell($w[2],6,'',0,0,'C');
									  $this->Cell($w[3],6,'',0,0,'C');
									  $this->Cell($w[4],6,'','C');
									  $this->Cell($w[5],6,'Subtotal','C');
									  $this->Cell($w[6],6,'',0,0,'C');
									  $this->Cell($w[6],6,'-$'.number_format($obj->unit_cost,2),0,0,'C');
									  $this->Ln();											

									  $per = .06;
									  $tax = $obj->unit_cost * $per;
									  
									  $this->SetFont('Times','',11);
									  $this->Cell($w[0],6,$obj->payment_type,0,0);
									  $this->SetFont('Times','',10);
									  $this->Cell($w[1],6,'',0,0);
									  $this->Cell($w[2],6,'',0,0,'C');
									  $this->Cell($w[3],6,'',0,0,'C');
									  $this->Cell($w[4],6,'','C');
									  $this->Cell($w[5],6,'Kentucky 6%','B','C');
									  $this->Cell($w[6],6,'','B','C');
									  $this->Cell($w[6],6,'-$'.number_format($tax,2),'B','0','C');
									  $this->Ln();
									  
									  $per = .06;
									  $total = $obj->unit_cost + $tax;
									  
									  $this->SetFont('Times','B',10);
									  $this->Cell($w[0],6,'',0,0);
									  $this->SetFont('Times','',10);
									  $this->Cell($w[1],6,'',0,0);
									  $this->Cell($w[2],6,'',0,0,'C');
									  $this->Cell($w[3],6,'',0,0,'C');
									  $this->Cell($w[4],6,'','C');
									  $this->SetFont('Times','B',12);
									  $this->Cell($w[5],6,'Total','C');
									  $this->Cell($w[6],6,'',0,0,'C');
									  $this->Cell($w[6],6,'-$'.number_format($total,2),0,0,'C');
									  $this->Ln(10);


									  $this->SetFont('Times','B',10);
									  $this->Cell($w[0],6,'Contract Details:','B',0);
									  $this->Cell($w[1],6,'','B',0);
									  $this->Ln();

									  $this->SetFont('Times','B',10);
									  $this->Cell($w[0],6,'Tracking #',0,0);
									  $this->Cell($w[1],6,'Contract #',0,0);
									  $this->Ln();
									  
									  $this->SetFont('Times','',11);
									  $this->Cell($w[0],6,$obj->product_sku,0,0);
									  $this->Cell($w[1],6,'999999999999',0,0);
									  
									  $this->Ln();	

									  // Line break
									  $this->Ln(20);
									  
									  if($find_records > $counter){
										  $this->header_flag = 1;
										  $this->AddPage();
									  }
									  $counter++;

							} 
						}

	// Line break
	$this->Ln(20);

	//$this->_endpage();
	//$this->AddPage();
}


function makeInvoice() {
for($i=1;$i<=40;$i++)
	$this->Cell(0,10,'Creating Invoice lines '.$this->invoiceid,0,1);

}


// Page footer
function Footer()
{
	// Position at 1.5 cm from bottom
	$this->SetY(-75);
	$this->SetFont('Times','',10);
	// Arial italic 8
	//$this->SetFont('Arial','I',10);
	// Page number
	$policy_1 = 'REFUNDS:  Refunds will be issued based upon the original method of payment.  All cash refunds over $55 will be issued via check';
	$policy_2 = 'mailed within 14 days from the return date.  Debit and credit card refunds will be processed to the original card within five to seven';
	$policy_3 = 'business days of the return date.  Any refund for one Buy One Get One (BOGO) item accepted for return will be at the price paid for the';
	$policy_4 = 'lower priced item, minus the restocking fee described above.  All sales are final for phones sold without contract. Prime Communications';
	$policy_5 = 'shall have no responsibility for any confidential,proprietary or personal information contained on a returned Device.  Users must ';
	$policy_6 = 'delete such information before returning any Device. Any rebate on a returned Device will be voided.';
	$policy_7 = 'ACKNOWLEDGEMENT:  I acknowledge that Prime Communications return policy and restocking fee, as set forth above, has been';
	$policy_8 = 'clearly explained to me.  ______________  (Purchaser�s Initials)';
	$this->Cell(0,10,$policy_1);
	$this->Ln(4);
	$this->Cell(0,10,$policy_2);
	$this->Ln(4);
	$this->Cell(0,10,$policy_3);
	$this->Ln(4);
	$this->Cell(0,10,$policy_4);
	$this->Ln(4);
	$this->Cell(0,10,$policy_5);
	$this->Ln(4);
	$this->Cell(0,10,$policy_6);
	$this->Ln(10);
	$this->Cell(0,10,$policy_7);
	$this->Ln(4);
	$this->Cell(0,10,$policy_8);
	$this->Ln(20);	
	
	//$this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}