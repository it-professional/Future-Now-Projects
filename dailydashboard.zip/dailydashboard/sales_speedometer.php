<script type="text/javascript" src="datepicker/formden.js"></script>
<link rel="stylesheet" href="datepicker/bootstrap-iso.css" />

<?php if(isset($_REQUEST['msg']) && $_REQUEST['msg'] == "success"): ?>
 <div style="color:#18ED58" id="successmsg">Invoices Generated Successfully</div>
 <?php endif; ?>
 
 
<div class="bootstrap-iso">
 <div class="container-fluid">
  <div class="row">
   <div class="col-md-6 col-sm-6 col-xs-12">
    <form action="speedometer.php" class="form-horizontal" method="post">
     <div class="form-group ">
      <label class="control-label col-sm-2 requiredField" for="storeid">Store ID</label>
      <div class="col-sm-10">
       <div class="input-group">
        <input class="form-control" id="storeid" name="storeid" placeholder="Store ID" type="text"/>
       </div>
      </div>
     </div>
     
     <div class="form-group ">
      <label class="control-label col-sm-2 requiredField" for="date">Date</label>
      <div class="col-sm-10">
       <div class="input-group">
        <input class="form-control" id="date" name="date" placeholder="MM/DD/YYYY" type="text"/>
       </div>
      </div>
     </div>
     
     <div class="form-group">
      <div class="col-sm-10 col-sm-offset-2">
       <input type="submit" name="submitform" value="Submit">
      </div>
     </div>
     
    </form>
   </div>
  </div>
 </div>
</div>

<script type="text/javascript" src="datepicker/jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="datepicker/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="datepicker/bootstrap-datepicker3.css"/>

<script>
	$(document).ready(function(){
		var date_input=$('input[name="date"]');
		var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
		date_input.datepicker({
			format: 'mm/dd/yyyy',
			container: container,
			todayHighlight: true,
			autoclose: true,
		})
	})
</script>