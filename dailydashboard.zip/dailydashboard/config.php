<?php
//set connection variables
$host = "primedatabase.cnx0wvt3enut.us-west-2.rds.amazonaws.com";
$username = "prime_drpl2";
$password = "Z1BQqeipYI663CS7";
$db_name = "prime_omega"; //database name


/*$host = "localhost";
$username = "root";
$password = "";
$db_name = "test2"; //database name*/

//connect to mysql server
$pconn = new mysqli($host, $username, $password, $db_name);

//check if any connection error was encountered
if(mysqli_connect_errno()) {
    echo "Error: Could not connect to database.";
    exit;
}
?>