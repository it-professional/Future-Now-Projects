<?php
define('FPDF_FONTPATH','font/');
require('speedometer_pdf_class.php');

$pdf = new PRIME_Invoice();

$storeid = $inputdate = '';
if(isset($_REQUEST['sid'])){
	$storeid = $_REQUEST['sid'];
}
if(isset($_REQUEST['date'])){
	$inputdate = $_REQUEST['date'];
}

$pdf->setData($storeid,$inputdate);

$pdf->AddPage('L');

$pdf->InvoiceHeader();
$pdf->Output('I','invoices/sales_speedometer.pdf');
?>
<script type="text/javascript">
	window.location.href = 'speedometer.php?msg=success';
</script>