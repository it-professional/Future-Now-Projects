<?php 
function imagetrim($im, $bgcol, $pad=null){
    // Calculate padding for each side.
    if (isset($pad)){
        $pada = explode(' ', $pad);
        if (isset($pada[3])){
            $p = array((int) $pada[0], (int) $pada[1], (int) $pada[2], (int) $pada[3]);
        }else if (isset($pada[2])){
            $p = array((int) $pada[0], (int) $pada[1], (int) $pada[2], (int) $pada[1]);
        }else if (isset($pada[1])){
            $p = array((int) $pada[0], (int) $pada[1], (int) $pada[0], (int) $pada[1]);
        }else{
            $p = array_fill(0, 4, (int) $pada[0]);
        }
    }else{
        $p = array_fill(0, 4, 0);
    }
    // Get the width and height of the image.
    $imw = imagesx($im);
    $imh = imagesy($im);
    // Set the X variables.
    $xmin = $imw;
    $xmax = 0;
    // find the endges.
    for ($iy=0; $iy<$imh; $iy++) {
        $first = true;
        for ($ix=0; $ix<$imw; $ix++) {
            $ndx = imagecolorat($im, $ix, $iy);
            if ($ndx != $bgcol) {
                if ($xmin > $ix) { $xmin = $ix; }
                if ($xmax < $ix) { $xmax = $ix; }
                if (!isset($ymin)) { $ymin = $iy; }
                $ymax = $iy;
                if ($first) { $ix = $xmax; $first = false; }
            }
        }
    }
    // The new width and height of the image. (not including padding)
    $imw = 1+$xmax-$xmin; // Image width in pixels
    $imh = 1+$ymax-$ymin; // Image height in pixels
    // Make another image to place the trimmed version in.
    $im2 = imagecreatetruecolor($imw+$p[1]+$p[3], $imh+$p[0]+$p[2]);
    // Make the background of the new image the same as the background of the old one.
    $bgcol2 = imagecolorallocate($im2, ($bgcol >> 16) & 0xFF, ($bgcol >> 8) & 0xFF, $bgcol & 0xFF);
    imagefill($im2, 0, 0, $bgcol2);
    // Copy it over to the new image.
    imagecopy($im2, $im, $p[3], $p[0], $xmin, $ymin, $imw, $imh);
    // To finish up, return the new image.
    return $im2;
}




if(isset($_REQUEST['category'])){
	$speedometer = 'speedometer_'.str_replace(' ','_',$_REQUEST['category']);
	$speedometer_image = str_replace(' ','_',$_REQUEST['category']);
}else{
	$speedometer = 'speedometer';
	$speedometer_image = 'speedometer_image';
}


if(file_exists("speedometer/images/$speedometer.png")){
	unlink("speedometer/images/$speedometer.png");
}
if(file_exists("speedometer/images/$speedometer_image.png")){
	unlink("speedometer/images/$speedometer_image.png");
}

$random = rand(100, 1000);
$data = explode(",", $_POST['data']);

$savefile = @file_put_contents("speedometer/images/$speedometer.png", base64_decode($data[1]));
if($savefile){
	
	$filename = "speedometer/images/$speedometer.png";
	$degrees = 90;
	$myim = imagecreatefrompng($filename);
	$myim_2 = imagetrim($myim, imagecolorallocate($myim, 0xFF, 0xFF, 0xFF), 2);
	$rotate = imagerotate($myim_2, $degrees, 0);
	imagepng($rotate,"speedometer/images/$speedometer_image.png");
	
	echo "Image generated";
}
?>