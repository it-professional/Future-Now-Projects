<?php

require('fpdf.php');

//define('EURO', chr(128) );

//define('EURO_VAL', 6.55957 );



class PRIME_Invoice extends FPDF

{

	public $header_counter = 1 ;

	

	public $host = "primedatabase.cnx0wvt3enut.us-west-2.rds.amazonaws.com";

	public $username = "prime_drpl2";

	public $password = "Z1BQqeipYI663CS7";

	public $db_name = "prime_omega"; //database name

	

	public $storeid;

	public $input_date;
	public $storename;
	public $reportdate;







function setData($get_storeid, $get_date){

	$this->storeid = $get_storeid;

	$this->input_date = $get_date;

	

}



		

// Page header

function Header()

{

	  $pconn = new mysqli($this->host, $this->username, $this->password, $this->db_name);	

	  

	  $head_query = mysqli_query($pconn,"CALL uspSalesDashboardStoreStat('$this->storeid','$this->input_date')");

	  if(mysqli_num_rows($head_query) > 0){	

	  	  $hcount = 1;			 

		  while($head_result = mysqli_fetch_array($head_query)){

			  

			  if($hcount == $this->header_counter)

			  {

				  $this->SetFont('Arial','I',50);

				  $this->SetTextColor(255,255,255);

				  $this->SetFillColor(192,192,192);

				  $this->Cell(30,25,$this->header_counter,0,0,'C',1);

				  

				  

				  //$this->SetFont('Arial','I',50);

				  //$this->SetTextColor(255,255,255);

				  //$this->SetFillColor(192,192,192);

				  $this->Cell(250,25,$head_result['stat_type'],0,0,'C',1);

				  $this->Ln(25);

			  }

			  

			  $hcount++;

		  }

	  }

}



function InvoiceHeader()

{

	 $pconn = new mysqli($this->host, $this->username, $this->password, $this->db_name);	

	 $query = mysqli_query($pconn,"CALL uspSalesDashboardStoreStat('$this->storeid','$this->input_date')");

	  $total_records = mysqli_num_rows($query);

	  $total_count = 1;

	  if($total_records > 0){

		  while($result = mysqli_fetch_array($query)){
				
				//print_r($result);
				
			  
			   $this->storename = $result['store_name'];
			   $this->reportdate = $result['dsr_date'] ;
			  //$this->SetFont('Times','B',25);

			  $speedometer_image = str_replace(' ','_',$result['stat_type']);

			  $this->Cell(80,150,$this->Image('speedometer/images/'.$speedometer_image.'.png',$this->GetX(),$this->GetY()),'R',0,'C',false);

			  //$this->SetFont('Times','',25);

			  //$this->Cell(110,25,$result['store_name'],'R',0,'C');

			  //$this->Cell(90,25,date('m/d/Y',strtotime($result['dsr_date'])),0,0,'C');	

			  //$this->Ln(25);

			  

			  //$this->Cell(90);

			  $this->Cell(180);

			  $this->Ln(8);

			  

			  if($result['label_1']){

				  $this->Cell(80);

				  $this->SetFont('Arial','',40);	

				  $this->Cell(110,22,'  '.$result['label_1'],0,0);

				  $this->Cell(90,22,'  '.$result['label_1_stat'],0,0,'C');

				  $this->Ln(22);

			  }

			  
			  if($result['label_2']){

				  $this->Cell(80);

				  $this->Cell(110,22,'  '.$result['label_2'],0,0);

				  $this->Cell(90,22,'  '.$result['label_2_stat'],0,0,'C');

				  $this->Ln(22);

			  }
			  
			  if($result['label_3']){

				  $this->Cell(80);

				  $this->Cell(110,22,'  '.$result['label_3'],0,0);

				  $this->Cell(90,22,'  '.$result['label_3_stat'],0,0,'C');

				  $this->Ln(22);

			  }
			  

			  $this->Cell(80);

			  $this->Cell(195,1,'','B',0);

			  $this->Ln(15);

		  

			  $stat_type = $result['stat_type'];

			  //if(trim($stat_type) != "Broadband"){

				  $pconn_2 = new mysqli($this->host, $this->username, $this->password, $this->db_name);
				
				  $emp_query = mysqli_query($pconn_2,"CALL uspSalesDashboardEmployeeStat('$this->storeid','$this->input_date','$stat_type')");

				  $emp_records = mysqli_num_rows($emp_query);

				  if($emp_records > 0){

					  $counter=1;
					  $conditoin_count = 1;
					  
					  while($emp_result = mysqli_fetch_array($emp_query)){

						  if(!empty($emp_result['employee_name'])){
							  
							  
							  if($conditoin_count == 1){
								  if($stat_type != "WTR" && $stat_type != "AAR"){
									  $this->Cell(80);
									  $this->Cell(120);
									  $this->SetFont('Arial','B',18);
									  if($stat_type == "IRPO"){
										  $this->Cell(38,5,'MPP',0,0,'C');
									  }else{
										  $this->Cell(38,5,'MTD',0,0,'C');
									  }
									  $this->Cell(4,10,'','R',0);
									  if($stat_type == "IRPO"){
										  $this->Cell(38,5,'MDPP',0,0,'C');
									  }else{
										  $this->Cell(38,5,'Run Rate',0,0,'C');
									  }
									  
									  $this->Cell(80);
									  $this->Cell(200);
									  $this->Ln(10);
								  }
							  }
								
							  $this->Cell(80);
							  if($emp_records <= 5){

								  $this->SetFont('Arial','',20);

							  }elseif($emp_records <= 7){

								  $this->SetFont('Arial','',17);

							  }else{

								  $this->SetFont('Arial','',15);

							  }

							  $this->Cell(120,5,'   '.$emp_result['employee_name'],0,0);
							  
							  
							  if($stat_type == "WTR" || $stat_type == "AAR"){
								  $this->Cell(80,5,$emp_result['stat_rr'],0,0,'C');
							  }else{
								  $this->Cell(38,5,$emp_result['stat_mtd'],0,0,'C');
								  $this->Cell(4,10,'','R',0);
								  $this->Cell(38,5,$emp_result['stat_rr'],0,0,'C');	
							  }

							  

							  if($emp_records <= 5){

								  $this->Ln(10);

							  }elseif($emp_records <= 7){

								  $this->Ln(7);

							  }else{

								  $this->Ln(6);

							  }

							  $counter++;

						  }
						  $conditoin_count++;
					  }

				  }

			 // }

			  

			  if($total_count < $total_records){

				  $this->header_counter = $total_count + 1;

				  $this->AddPage('L');

			  }

			  

			  $total_count++;

		  }

	  }

	

}





// Page footer

function Footer()

{

	//$this->Ln(20);

	$this->SetY(-25);
	
	$this->SetFont('Arial','',18);
	$this->Cell(75,8,$this->storename,'B',1);
	$this->Cell(80,8,date('m/d/Y',strtotime($this->reportdate)),0,0);
	$this->AlignedImage('image/prime-logo.png', 280, null, true, false, null, 8);	

}

}

?>