<?php if(isset($_REQUEST['msg']) && $_REQUEST['msg'] == "success"){

		echo "Invoice Generated" ;

		exit();

}?>

<link class="include" rel="stylesheet" type="text/css" href="speedometer/jquery.jqplot.min.css" />

<link type="text/css" rel="stylesheet" href="speedometer/syntaxhighlighter/styles/shCoreDefault.min.css" />

<link type="text/css" rel="stylesheet" href="speedometer/syntaxhighlighter/styles/shThemejqPlot.min.css" />

<script class="include" type="text/javascript" src="speedometer/jquery.min.js"></script>



<script class="include" type="text/javascript" src="speedometer/jquery.jqplot.min.js"></script>

<script type="text/javascript" src="speedometer/syntaxhighlighter/scripts/shCore.min.js"></script>

<script type="text/javascript" src="speedometer/syntaxhighlighter/scripts/shBrushJScript.min.js"></script>

<script type="text/javascript" src="speedometer/syntaxhighlighter/scripts/shBrushXml.min.js"></script>

<script class="include" type="text/javascript" src="speedometer/plugins/jqplot.meterGaugeRenderer.min.js"></script>



<script src="speedometer/jquery-ui.js"></script>

<script src="speedometer/html2canvas.js"></script>



<?php include('config.php'); ?>



<?php 

	/*$query = mysqli_query($pconn,"SELECT * FROM prime_store_page_visitor");

	$total_records = mysqli_num_rows($query);

	if($total_records > 0){

		  while($result = mysqli_fetch_array($query)){

			  echo "<br><br>";

			  print_r($result);

		  }

	  }

	  die; exit();*/

?>

<?php if(isset($_GET['eid']) && isset($_GET['sid']) && isset($_GET['jid']) && isset($_GET['date'])){

		  $get_employee_id = $_GET['eid'];

		  $get_store_id = $_GET['sid'];

		  $get_job_id = $_GET['jid'];

		  $get_date = $_GET['date'];

		  

		  $qresult = mysqli_query($pconn,"INSERT INTO prime_store_page_visitor(employee_id,store_id,job_id,dsr_date,visit_area,visit_time) VALUES($get_employee_id,'$get_store_id',$get_job_id,'$get_date','pdfdashboard',NOW())");

	  }

?>



<?php $store_id = '';

      $input_date = '';

	  if(isset($_REQUEST['sid'])){

		  $store_id = $_REQUEST['sid'];

	  }

	  if(isset($_REQUEST['date'])){

		  $input_date = $_REQUEST['date'];

	  }

	  

	  if(isset($_REQUEST['cc']))

	  {

		  $canvas_count = $_REQUEST['cc']; 

	  }else{

		  $canvas_count = 1; 

	  }

	  

	  $counter = 1;

	  $query = mysqli_query($pconn,"CALL uspSalesDashboardStoreStat('$store_id','$input_date')");

	  $total_records = mysqli_num_rows($query);

	  if($total_records > 0){

		  while($result = mysqli_fetch_array($query)){

			  

			  if($canvas_count == $counter){

?>

                <div id="canvas<?php echo $counter; ?>" class="plot" style="width:550px;height:320px;"></div>

                

                <script type="text/javascript" class="code">

                $(document).ready(function(){

					<?php $state_1 = $state_2 = 0;

						  if($result['label_1_stat']){

							$state_1 = str_replace(array('%','>','<','=','$'),'',$result['label_1_stat']);

						  }

						  if($result['label_3_stat']){

							$state_2 = str_replace(array('%','>','<','=','$'),'',$result['label_3_stat']);

						  }

						  

						  if($state_1 > 0 && $state_2 > 0){

							  $state_percentage = round(($state_1/$state_2)*100);

						  }else{

							  $state_percentage = 0;

						  }

						  

						  if((trim($result['stat_type']) == "Total Opps") && ($result['label_3_stat'] > 0)){

							  $state_percentage = str_replace(array('%','>','<','=','$'),'',$result['label_3_stat']);

						  }

						  

						  if((trim($result['stat_type']) == "Go Phone") && ($result['label_3_stat'] > 0)){

							  $state_percentage = str_replace(array('%','>','<','=','$'),'',$result['label_3_stat']);

						  }

						  

					?>

					

					<?php if(trim($result['stat_type']) == "WTR"): ?>

						   

						   <?php if($result['label_1_stat']): $state_percentage = str_replace(array('%','>','<','=','$'),'',$result['label_1_stat']); elseif($result['label_3_stat']): $state_percentage = str_replace(array('%','>','<','=','$'),'',$result['label_3_stat']); else: $state_percentage = '0'; endif; ?>

						s1 = [<?php echo $state_percentage; ?>];

					

					<?php elseif(trim($result['stat_type']) == "IPRO" || trim($result['stat_type']) == "ATV" || trim($result['stat_type']) == "Broadband" || trim($result['stat_type']) == "CRU" || trim($result['stat_type']) == "Go Phone" || trim($result['stat_type']) == "AAR"): ?>

						s1 = [<?php echo $state_percentage; ?>];

						

					<?php else: ?>

						s1 = [<?php if($result['label_3_stat']): echo str_replace(array('%','>','<','=','$'),'',$result['label_3_stat']); elseif($result['label_1_stat']): echo str_replace(array('%','>','<','=','$'),'',$result['label_1_stat']); else: echo '0'; endif; ?>];

					<?php endif; ?>

                

                   plot0 = $.jqplot('canvas<?php echo $counter; ?>',[s1],{

                       seriesDefaults: {

                           renderer: $.jqplot.MeterGaugeRenderer,

                           rendererOptions: {

							   <?php if(trim($result['stat_type']) == "WTR"): ?>      

                               		label: '<?php if($result['label_1_stat']): echo str_replace(array('>','<','=','$'),'',$result['label_1_stat']); elseif($result['label_3_stat']): echo str_replace(array('>','<','=','$'),'',$result['label_3_stat']); endif; ?>',

							   

							   

							   <?php elseif(trim($result['stat_type']) == "IPRO" || trim($result['stat_type']) == "ATV" || trim($result['stat_type']) == "Broadband" || trim($result['stat_type']) == "CRU" || trim($result['stat_type']) == "Go Phone" || trim($result['stat_type']) == "AAR"): ?>									

									<?php if($state_percentage > 0): ?>

										label: '<?php echo $state_percentage; ?>%',

									<?php endif; ?>

							   

							   <?php else: ?>

							 		label: '<?php if($result['label_3_stat']): echo str_replace(array('>','<','=','$'),'',$result['label_3_stat']); elseif($result['label_1_stat']): echo str_replace(array('>','<','=','$'),'',$result['label_1_stat']); endif; ?>',  		

							   <?php endif; ?>

                               labelPosition: 'bottom', 

							   <?php //if(trim($result['stat_type']) == "AAR"): ?>       

                               //ticks: [0.50,1.0,1.5,2.0,2.5],

							   <?php if($state_percentage > 100): ?>       

                               ticks: [0,50,100,150,200],

							   <?php else: ?>

							   ticks: [0,25,50,75,100],

							   <?php endif;?>

							   

                           }

                       }

                   });

                });

				

				<?php if($counter < $total_records): ?>

				$(function(){

					  div_content = document.querySelector("#canvas<?php echo $counter; ?>");

					  html2canvas(div_content).then(function(canvas) {

						  data = canvas.toDataURL('image/png');

						  save_img(data,'<?php echo str_replace(' ','_',trim($result['stat_type'])); ?>');

						  document.getElementById("canvas<?php echo $counter; ?>").style.display = "none";

					  });

				});

				<?php else: ?>

				$(function(){

					  div_content = document.querySelector("#canvas<?php echo $counter; ?>");

					  html2canvas(div_content).then(function(canvas) {

						  data = canvas.toDataURL('image/png');

						  save_img_last(data,'<?php echo str_replace(' ','_',trim($result['stat_type'])); ?>');

						  document.getElementById("canvas<?php echo $counter; ?>").style.display = "none";

					  });

				});

				<?php endif; ?>

                </script>

                

<?php

			  }

		  $counter++;

		  }

	  }

	  

	  $canvas_count++;

?>



<script type="text/javascript">	



  function save_img(data,cat){

	  $.post('save_speedometer.php?category='+cat, {data: data}, function(res){

		  if(res != ''){

			  window.location.href = 'speedometer.php?cc=<?php echo $canvas_count; ?>&sid=<?php echo $store_id; ?>&date=<?php echo $input_date; ?>';

		  }

		  else{

			  alert('something wrong');

		  }

	  });

  }

  function save_img_last(data,cat){

	  $.post('save_speedometer.php?category='+cat, {data: data}, function(res){

		  if(res != ''){

			  window.location.href = 'sales_invoice.php?sid=<?php echo $store_id; ?>&date=<?php echo $input_date; ?>';

		  }

		  else{

			  alert('something wrong');

		  }

	  });

  }

</script>