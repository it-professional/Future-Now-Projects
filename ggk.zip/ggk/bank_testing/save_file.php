<?php header("Content-disposition: attachment; filename=test.csv");
header("Content-type: application/octet-stream");
readfile("https://secure.bankofamerica.com/myaccounts/details/deposit/download-transactions.go?adx=608ff21ed17bd8e653b33e9bdf60673658616c7d8a47bd624c7844760e2ea4c2&downloadTransactionType=customRange&searchBean.timeFrameStartDate=04/05/2017&searchBean.timeFrameEndDate=04/05/2017&formatType=csv");

exit();



header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename=aamir.csv');
readfile('https://secure.bankofamerica.com/myaccounts/details/deposit/download-transactions.go?adx=608ff21ed17bd8e653b33e9bdf60673658616c7d8a47bd624c7844760e2ea4c2&downloadTransactionType=customRange&searchBean.timeFrameStartDate=04/05/2017&searchBean.timeFrameEndDate=04/05/2017&formatType=csv'); 
exit;


?>