<?php 
$output = '<ul class="AccountItems list-view-tour" id="Deposits"> 
       <!--depositsOutage DB value: false-->

    <li>
        <div class="AccountItem AccountItemDeposit" data-accounttype="Checking" data-adx="608ff21ed17bd8e653b33e9bdf60673658616c7d8a47bd624c7844760e2ea4c2">
            <span class="AccountName"><i class="aor-sprite acctlogo"></i><a name="DDA_SB_details" href="/myaccounts/brain/redirect.go?source=overview&amp;target=acctDetails&amp;adx=608ff21ed17bd8e653b33e9bdf60673658616c7d8a47bd624c7844760e2ea4c2">100 WWWhite - 9744</a></span>
                <div class="AccountBalance" data-adx="608ff21ed17bd8e653b33e9bdf60673658616c7d8a47bd624c7844760e2ea4c2"><span class="balanceValue TL_NPI_L1">$0.00</span></div>
            <div class="gripperContainer Invisible aor-sprite"><span class="ada-hidden">Gripper</span></div>
                        
        </div>
        <i class="aor-sprite account-details-indicator"></i>
    </li>
								
       <!--depositsOutage DB value: false-->

    <li>
        <div class="AccountItem AccountItemDeposit" data-accounttype="Checking" data-adx="98ab55d0a1c85cd4f773fb5129b44647d4e40da4884415a0b3c3f888eba4eac1">
            <span class="AccountName"><i class="aor-sprite acctlogo"></i><a name="DDA_SB_details" href="/myaccounts/brain/redirect.go?source=overview&amp;target=acctDetails&amp;adx=98ab55d0a1c85cd4f773fb5129b44647d4e40da4884415a0b3c3f888eba4eac1">101 SEM - 9757</a></span>
                <div class="AccountBalance" data-adx="98ab55d0a1c85cd4f773fb5129b44647d4e40da4884415a0b3c3f888eba4eac1"><span class="balanceValue TL_NPI_L1">$0.00</span></div>
            <div class="gripperContainer Invisible aor-sprite"><span class="ada-hidden">Gripper</span></div>
                        
        </div>
        <i class="aor-sprite account-details-indicator"></i>
    </li>
</ul>' ;



$dom = new DOMDocument;
$dom->loadXML($output);
$lis = $dom->getElementsByTagName('li');
foreach ($lis as $li) {
	$nodes = $li->getElementsByTagName('a');
	$name = $li->nodeValue;
	$explode_name = explode(" ",trim($name));
	$file_name = $explode_name[0];
	//echo "<br><br>file name is: ".$file_name;
	
	$link = $nodes->item(0)->getAttribute('href');
	$parseurl = parse_str($link,$result);
	$adx = $result['adx'];
	
	//$download_link = "https://secure.bankofamerica.com/myaccounts/details/deposit/download-transactions.go?adx=$adx&downloadTransactionType=customRange&searchBean.timeFrameStartDate=03/13/2017&searchBean.timeFrameEndDate=03/13/2017&formatType=csv";
	
	//echo "<br><br>downlaod link is: <br>".$download_link;
	
	
	//file_put_contents($file_name.".csv", file_get_contents($download_link));
	
	
	
	//$url  = 'http://www.example.com/a-large-file.zip';
    //$path = '/path/to/a-large-file.zip';

    /*$fp = fopen($file_name.".csv", 'w');

    $ch = curl_init($download_link);
    curl_setopt($ch, CURLOPT_FILE, $fp);

    $data = curl_exec($ch);

    curl_close($ch);
    fclose($fp);*/
	
	
	$source = "https://secure.bankofamerica.com/myaccounts/details/deposit/download-transactions.go?adx=$adx&downloadTransactionType=customRange&searchBean.timeFrameStartDate=03/13/2017&searchBean.timeFrameEndDate=03/13/2017&formatType=csv";
	
	//echo $source."<br><br>";
	//file_put_contents($file_name.".csv", file_get_contents(trim($source)));
	//echo "<br>fiel name is: ".$source;

	
	//file_put_contents($file_name.".csv", fopen(trim($source), 'r'));
	//download(trim($source));
	//echo "<br><br><a href='$source'>Download</a>";
	
	
	
	//$source = 'http://www.google.com';
	$destination = $file_name.".csv";

	//copy($destination,$source);
	
	
	
	/*$file_name = $file_name.".csv";
	$file_url = $source;
	header('Content-Type: application/csv');
	//header("Content-Transfer-Encoding: Binary"); 
	//header("Content-disposition: attachment; filename=\"".$file_name."\""); 
	readfile($file_url);*/
	
	
	$new_file_name = $file_name.".csv";
	header('Content-Type: application/csv');
	header("Content-Disposition: attachment; filename=\"".$file_name."\"");
	header('Pragma: no-cache');
	readfile($source);
	
	
	
	
}



function url_get_contents ($url) {
    if (function_exists('curl_exec')){ 
        $conn = curl_init($url);
        curl_setopt($conn, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($conn, CURLOPT_FRESH_CONNECT,  true);
        curl_setopt($conn, CURLOPT_RETURNTRANSFER, 1);
        $url_get_contents_data = (curl_exec($conn));
        curl_close($conn);
    }elseif(function_exists('file_get_contents')){
        $url_get_contents_data = file_get_contents($url);
    }elseif(function_exists('fopen') && function_exists('stream_get_contents')){
        $handle = fopen ($url, "r");
        $url_get_contents_data = stream_get_contents($handle);
    }else{
        $url_get_contents_data = false;
    }
return $url_get_contents_data;
} 


function storeUrlToFilesystem($url, $localFile) {
	try {
		$data = file_get_contents($url);
		$handle = fopen($localFile, "w");
		fwrite($handle, $data);
		fclose($handle);
		return true;	
	} catch (Exception $e) {
    		echo 'Caught exception: ',  $e->getMessage(), "\n";
	}
	return false;
}

function download($filename){
  if(!empty($filename)){
    // Specify file path.
    $path = ''; // '/uplods/'
    $download_file =  $path.$filename;
    // Check file is exists on given path.
    if(file_exists($download_file))
    {
      // Getting file extension.
      $extension = explode('.',$filename);
      $extension = $extension[count($extension)-1]; 
      // For Gecko browsers
      header('Content-Transfer-Encoding: binary');  
      header('Last-Modified: ' . gmdate('D, d M Y H:i:s', filemtime($path)) . ' GMT');
      // Supports for download resume
      header('Accept-Ranges: bytes');  
      // Calculate File size
      header('Content-Length: ' . filesize($download_file));  
      header('Content-Encoding: none');
      // Change the mime type if the file is not PDF
      header('Content-Type: text/csv');  
      // Make the browser display the Save As dialog
      header('Content-Disposition: attachment; filename=' . $filename);  
      readfile($download_file); 
      exit;
    }
    else
    {
      echo 'File does not exists on given path';
    }
 
 }
}

?>