<a href="save_file.php">CLick here</a>
<?php

$file = file_get_contents('https://secure.bankofamerica.com/myaccounts/details/deposit/download-transactions.go?adx=608ff21ed17bd8e653b33e9bdf60673658616c7d8a47bd624c7844760e2ea4c2&downloadTransactionType=customRange&searchBean.timeFrameStartDate=04/05/2017&searchBean.timeFrameEndDate=04/05/2017&formatType=csv', FILE_USE_INCLUDE_PATH);

echo "<br><br>File data is: ";
print_r($file);
exit(); 

$file = 'https://secure.bankofamerica.com/myaccounts/details/deposit/download-transactions.go?adx=608ff21ed17bd8e653b33e9bdf60673658616c7d8a47bd624c7844760e2ea4c2&downloadTransactionType=customRange&searchBean.timeFrameStartDate=04/05/2017&searchBean.timeFrameEndDate=04/05/2017&formatType=csv';


if (file_exists($file)) {
	echo "<br>file exists.";
    header('Content-Description: File Transfer');
    header('Content-Type: application/csv');
    header('Content-Disposition: attachment; filename="here.csv"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file));
    readfile($file);
    exit;
}else{
	echo "no file exits";
}


?>