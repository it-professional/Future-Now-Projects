<?php 
$output = '<ul class="AccountItems list-view-tour" id="Deposits"> 
       <!--depositsOutage DB value: false-->

    <li>
        <div class="AccountItem AccountItemDeposit" data-accounttype="Checking" data-adx="608ff21ed17bd8e653b33e9bdf60673658616c7d8a47bd624c7844760e2ea4c2">
            <span class="AccountName"><i class="aor-sprite acctlogo"></i><a name="DDA_SB_details" href="/myaccounts/brain/redirect.go?source=overview&amp;target=acctDetails&amp;adx=608ff21ed17bd8e653b33e9bdf60673658616c7d8a47bd624c7844760e2ea4c2">100 WWWhite - 9744</a></span>
                <div class="AccountBalance" data-adx="608ff21ed17bd8e653b33e9bdf60673658616c7d8a47bd624c7844760e2ea4c2"><span class="balanceValue TL_NPI_L1">$0.00</span></div>
            <div class="gripperContainer Invisible aor-sprite"><span class="ada-hidden">Gripper</span></div>
                        
        </div>
        <i class="aor-sprite account-details-indicator"></i>
    </li>
								
       <!--depositsOutage DB value: false-->

    <li>
        <div class="AccountItem AccountItemDeposit" data-accounttype="Checking" data-adx="98ab55d0a1c85cd4f773fb5129b44647d4e40da4884415a0b3c3f888eba4eac1">
            <span class="AccountName"><i class="aor-sprite acctlogo"></i><a name="DDA_SB_details" href="/myaccounts/brain/redirect.go?source=overview&amp;target=acctDetails&amp;adx=98ab55d0a1c85cd4f773fb5129b44647d4e40da4884415a0b3c3f888eba4eac1">101 SEM - 9757</a></span>
                <div class="AccountBalance" data-adx="98ab55d0a1c85cd4f773fb5129b44647d4e40da4884415a0b3c3f888eba4eac1"><span class="balanceValue TL_NPI_L1">$0.00</span></div>
            <div class="gripperContainer Invisible aor-sprite"><span class="ada-hidden">Gripper</span></div>
                        
        </div>
        <i class="aor-sprite account-details-indicator"></i>
    </li>
						
</ul>' ;

?>

<a href="https://secure.bankofamerica.com/myaccounts/details/deposit/download-transactions.go?adx=608ff21ed17bd8e653b33e9bdf60673658616c7d8a47bd624c7844760e2ea4c2&downloadTransactionType=customRange&searchBean.timeFrameStartDate=04/05/2017&searchBean.timeFrameEndDate=04/05/2017&formatType=csv" download="aamir.csv">CLick here</a>

<?php
exit();



set_time_limit(0);

$url = 'https://secure.bankofamerica.com/myaccounts/details/deposit/download-transactions.go?adx=608ff21ed17bd8e653b33e9bdf60673658616c7d8a47bd624c7844760e2ea4c2&downloadTransactionType=customRange&searchBean.timeFrameStartDate=04/05/2017&searchBean.timeFrameEndDate=04/05/2017&formatType=csv';
$file = basename($url);

$fp = fopen($file, 'w');

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_FILE, $fp);

$data = curl_exec($ch);

curl_close($ch);
fclose($fp);

header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename='.basename($file));
header('Content-Transfer-Encoding: binary');
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Content-Length: ' . filesize($file));
ob_clean();
flush();
readfile($file);
exit;





$ch = curl_init();
$source = "https://secure.bankofamerica.com/myaccounts/details/deposit/download-transactions.go?adx=608ff21ed17bd8e653b33e9bdf60673658616c7d8a47bd624c7844760e2ea4c2&downloadTransactionType=customRange&searchBean.timeFrameStartDate=04/05/2017&searchBean.timeFrameEndDate=04/05/2017&formatType=csv";
curl_setopt($ch, CURLOPT_URL, $source);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$data = curl_exec ($ch);
curl_close ($ch);

$destination = "invoices/testing.csv";
$file = fopen($destination, "w+");
fputs($file, $data);
fclose($file);


exit();



curl_setopt($ch, CURLOPT_URL, $host);
    curl_setopt($ch, CURLOPT_VERBOSE, 1);
    
    curl_setopt($ch, CURLOPT_AUTOREFERER, false);
	
    curl_setopt($ch, CURLOPT_REFERER, "https://www.bankofamerica.com");
    curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
    





$copydata = copy('');

exit();

$file = 'https://www.bankofamerica.com/?TYPE=33554433&amp;REALMOID=06-000aea23-f082-1f06-b383-082c0a2840b5&amp;GUID=&amp;SMAUTHREASON=0&amp;METHOD=GET&amp;SMAGENTNAME=-SM-aqqfzgjeqy8S5m8u%2b8h6gZjIC5XifZeAeb5F64xMRkTo1mmai3SO2HDPyq%2bg0LdA&amp;TARGET=-SM-HTTPS%3a%2f%2fsecure%2ebankofamerica%2ecom%2fmyaccounts%2fdetails%2fdeposit%2fdownload--transactions%2ego%3fadx%3d608ff21ed17bd8e653b33e9bdf60673658616c7d8a47bd624c7844760e2ea4c2%26downloadTransactionType%3dcustomRange%26searchBean%2etimeFrameStartDate%3d04%2f05%2f2017%26searchBean%2etimeFrameEndDate%3d04%2f05%2f2017%26formatType%3dcsv';




//$file = 'monkey.gif';

if (file_exists($file)) {
	echo "File exits";
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename='.basename($file));
    header('Content-Transfer-Encoding: binary');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file));
    ob_clean();
    flush();
    readfile($file);
    exit;
}else{
	echo "<br><br>No File exists.";
}


exit();









$handle = fopen($filename,"r");

if ($handle) {
    while (($line = fgets($handle)) !== false) {
        echo "<br>line is: ";
		print_r($line);
    }

    fclose($handle);
} else {
	echo "<br><br>in else ...";
    
}

print_r($handle);
exit();

$dowloadname = 'invoices/PHPDownload.csv';

//Header("content-type:application/octet-stream"); 
//Header("Accept-Ranges: bytes");
//Header("Accept-Length: ".filesize($filename));
//Header("Content-Disposition: attachment; filename=".$dowloadname);
if(file_exists($filename) && $fp=fopen($filename,"r"))  //file exists and open it 
{ 
    fwrite($fp,filesize($filename));    //read write to the browser 
    fclose($fp); 
}


exit();


$file_data = file_get_contents('https://secure.bankofamerica.com/myaccounts/details/deposit/download-transactions.go?adx=608ff21ed17bd8e653b33e9bdf60673658616c7d8a47bd624c7844760e2ea4c2&downloadTransactionType=customRange&searchBean.timeFrameStartDate=04/05/2017&searchBean.timeFrameEndDate=04/05/2017&formatType=csv');


file_put_contents(
    'invoices/testing.csv',
    file_get_contents( 'https://secure.bankofamerica.com/myaccounts/details/deposit/download-transactions.go?adx=608ff21ed17bd8e653b33e9bdf60673658616c7d8a47bd624c7844760e2ea4c2&downloadTransactionType=customRange&searchBean.timeFrameStartDate=04/05/2017&searchBean.timeFrameEndDate=04/05/2017&formatType=csv' )
);

echo "<br><br>File data is: <br><br>";
//print_r($file_data);
exit();

  $output_filename = "testfile.csv";

    $host = "https://secure.bankofamerica.com/myaccounts/details/deposit/download-transactions.go?adx=608ff21ed17bd8e653b33e9bdf60673658616c7d8a47bd624c7844760e2ea4c2&downloadTransactionType=customRange&searchBean.timeFrameStartDate=04/05/2017&searchBean.timeFrameEndDate=04/05/2017&formatType=csv";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $host);
    curl_setopt($ch, CURLOPT_VERBOSE, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_AUTOREFERER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_REFERER, "https://www.bankofamerica.com");
    curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    $result = curl_exec($ch);
    curl_close($ch);

    print_r($result); // prints the contents of the collected file before writing..


    // the following lines write the contents to a file in the same directory (provided permissions etc)
    $fp = fopen($output_filename, 'w');
    fwrite($fp, $result);
    fclose($fp);
	
exit();




$dom = new DOMDocument;
$dom->loadXML($output);
$lis = $dom->getElementsByTagName('li');
foreach ($lis as $li) {
	$nodes = $li->getElementsByTagName('a');
	$name = $li->nodeValue;
	$explode_name = explode(" ",trim($name));
	$file_name = $explode_name[0];
	//echo "<br><br>file name is: ".$file_name;
	
	$link = $nodes->item(0)->getAttribute('href');
	$parseurl = parse_str($link,$result);
	$adx = $result['adx'];
	
	/*$source = "https://secure.bankofamerica.com/myaccounts/details/deposit/download-transactions.go?adx=$adx&downloadTransactionType=customRange&searchBean.timeFrameStartDate=03/13/2017&searchBean.timeFrameEndDate=03/13/2017&formatType=csv";*/
	
	//$destination = $file_name.".csv";
	
	
	
	
	$curl = curl_init();
		  curl_setopt_array($curl, array(
	  CURLOPT_URL => "https://secure.bankofamerica.com/myaccounts/details/deposit/download-transactions.go?adx=608ff21ed17bd8e653b33e9bdf60673658616c7d8a47bd624c7844760e2ea4c2&downloadTransactionType=customRange&searchBean.timeFrameStartDate=04/05/2017&searchBean.timeFrameEndDate=04/05/2017&formatType=csv",
	  
	
	  CURLOPT_RETURNTRANSFER => true,
	
	  CURLOPT_ENCODING => "",
	
	  CURLOPT_MAXREDIRS => 10,
	
	  CURLOPT_TIMEOUT => 30,
	  
	  CURLOPT_SSL_VERIFYPEER => false,
	
	  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	
	  CURLOPT_CUSTOMREQUEST => "GET",
	
	  CURLOPT_HTTPHEADER => array(
	
		
		"cache-control: no-cache",
	
	
	  ),
	
	));
	
	
	//curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	
	$response = curl_exec($curl);
	
	$err = curl_error($curl);
	
	
	
	curl_close($curl);
	
	
	
	if ($err) {
	
	  echo "cURL Error #:" . $err;
	
	} else {
		echo "<br><br>Response is: ";
		print_r($response);
		
		$destination = "invoices/".$file_name."_wsr_report.csv";
		$file = fopen($destination, "w+");
		fputs($file, $response);
		fclose($file);
	}
	

}
?>