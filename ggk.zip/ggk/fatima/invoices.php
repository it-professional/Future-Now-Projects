<?php 
error_reporting(0);	
include 'PDFMerger.php';
			
$pdf = new PDFMerger;
$dir = "invoices/";

if (is_dir($dir)){
  if ($dh = opendir($dir)){
    while (($file = readdir($dh)) !== false){
		$store_name = '';
		if ($file != "." && $file != "..") {
			$explode_file = explode('-',$file);
			if($explode_file[0])
			{	
				$store_name = trim($explode_file[0]);
				
				$searchString = $store_name;
				$all_files = glob('invoices/*',GLOB_NOSORT);;
				$filesFound = array();
				
				foreach($all_files as $find_file) {
					$name = pathinfo($find_file, PATHINFO_FILENAME);
					
					$search_position = strpos(trim($name), trim($searchString));
					
					if(is_numeric($search_position)) {
						 $filesFound[] = $find_file;
					} 
				}
				
				if(count($filesFound) > 0){
					
					$pdf = new PDFMerger;
					
					if(count($filesFound) == 1){
						$pdf->addPDF("$filesFound[0]")->merge('file', "combined_invoices/$store_name.pdf");
					}elseif(count($filesFound) == 2){
						$pdf->addPDF("$filesFound[0]")
							->addPDF("$filesFound[1]")
							->merge('file', "combined_invoices/$store_name.pdf");
					}elseif(count($filesFound) == 3){
						$pdf->addPDF("$filesFound[0]")
							->addPDF("$filesFound[1]")
							->addPDF("$filesFound[2]")
							->merge('file', "combined_invoices/$store_name.pdf");
					}elseif(count($filesFound) == 4){
						$pdf->addPDF("$filesFound[0]")
							->addPDF("$filesFound[1]")
							->addPDF("$filesFound[2]")
							->addPDF("$filesFound[3]")
							->merge('file', "combined_invoices/$store_name.pdf");
					}elseif(count($filesFound) == 5){
						$pdf->addPDF("$filesFound[0]")
							->addPDF("$filesFound[1]")
							->addPDF("$filesFound[2]")
							->addPDF("$filesFound[3]")
							->addPDF("$filesFound[4]")
							->merge('file', "combined_invoices/$store_name.pdf");
					}elseif(count($filesFound) == 6){
						$pdf->addPDF("$filesFound[0]")
							->addPDF("$filesFound[1]")
							->addPDF("$filesFound[2]")
							->addPDF("$filesFound[3]")
							->addPDF("$filesFound[4]")
							->addPDF("$filesFound[5]")
							->merge('file', "combined_invoices/$store_name.pdf");
					}elseif(count($filesFound) == 7){
						$pdf->addPDF("$filesFound[0]")
							->addPDF("$filesFound[1]")
							->addPDF("$filesFound[2]")
							->addPDF("$filesFound[3]")
							->addPDF("$filesFound[4]")
							->addPDF("$filesFound[5]")
							->addPDF("$filesFound[6]")
							->merge('file', "combined_invoices/$store_name.pdf");
					}elseif(count($filesFound) == 8){
						$pdf->addPDF("$filesFound[0]")
							->addPDF("$filesFound[1]")
							->addPDF("$filesFound[2]")
							->addPDF("$filesFound[3]")
							->addPDF("$filesFound[4]")
							->addPDF("$filesFound[5]")
							->addPDF("$filesFound[6]")
							->addPDF("$filesFound[7]")
							->merge('file', "combined_invoices/$store_name.pdf");
					}
					
					foreach($filesFound as $foundfile){
						unlink($foundfile);
					}
				}
			}
			else{
				echo "<br>there is no exploded file.";
			}
		}
		//echo "<br><br>in while loop: file name is: ".$file;
    }
   echo "All Done." ;
   closedir($dh);
  }
}else{
	echo "There is no directory.";
}