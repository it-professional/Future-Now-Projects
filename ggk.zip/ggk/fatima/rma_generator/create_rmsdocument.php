<?php 
if(isset($_REQUEST['rmanum'])){
	$search_type = '';
	$search_file = '';
	$search_file = $_REQUEST['rmanum'];
	$search_type = $_REQUEST['type'];
	
	$directory = '/home/myprimeportal/public_html/sites/default/files/new_rma';
	
	$ups = $invoice = $simple = $need_invoice = 0;
	$handler = opendir($directory);
	while ($file = readdir($handler)) {
		if ($file != "." && $file != "..") {
			
			if($file == $search_file.".pdf"){
				$simple = 1;
			}
			
			if(($search_type == 'BRE') || ($search_type == 'DOA')) {
				$need_invoice = 1;
				if($file == "invoice_".$search_file.".pdf"){
					$invoice = 1;
				}
			}			
			
			if($file == "ups_".$search_file.".pdf"){
				$ups = 1;
			}
		}
	}
	
	//echo $search_type;
	//echo $invoice;
		//echo $simple;
	
	if($need_invoice == 1 && $ups == 1 && $invoice == 1 && $simple == 1){
			
			error_reporting(0);
			include 'PDFMerger.php';
			
			$pdf = new PDFMerger;
			
			$pdf->addPDF($directory.'/'.$search_file.'.pdf')
				->addPDF($directory.'/invoice_'.$search_file.'.pdf')
				->addPDF($directory.'/ups_'.$search_file.'.pdf')
				->merge('browser');
			
	}	else if($need_invoice == 0 && $ups == 1 && $simple == 1){
		error_reporting(1);
		include 'PDFMerger.php';
		
		$pdf = new PDFMerger;
		
		$pdf->addPDF($directory.'/'.$search_file.'.pdf')
			->addPDF($directory.'/ups_'.$search_file.'.pdf')
			->merge('browser');	
	
	} else{
		echo '<h3>Something went wrong when generating rma info. The RMA team has been informed. Please check back in couple of hours or contact RMA support @ hbudhwani@primecomms.com.</h3>' ;
		
		$headers = "MIME-Version: 1.0\r\n";
		$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
		$headers .= "From: myprimeportal.com";
		$headers .= "From: portal@primecomms.com" . "\r\n" .
					"CC: ahazoor@primecomms.com";
		
		$to = 'hbudhwani@primecomms.com';
		$subject = 'Issues generating rma pdf for rsm # '.$search_file;
		$body .= 'Issues generating rma pdf for rsm # '.$search_file.'<br>';
		$body .= 'LP: '.$simple.'<br>';
		$body .= 'Invoive: '.$invoice.'<br>';
		$body .= 'UPS: '.$ups.'<br>';
		$body .= 'Status: '.$search_type.'<br>';
		
		mail($to,$subject,$body,$headers);
	}
}
?>