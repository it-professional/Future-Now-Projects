<?php if(isset($_POST['invoices_list']) && !empty($_POST['invoices_list'])){
	$invoices = $_POST['invoices_list'];
	
	if(isset($_POST['date'])){
		$date = $_POST['date'];
	}else{
		$date = date('m/d/Y');
	}
	
	if(isset($_POST['end_date'])){
		$end_date = $_POST['end_date'];
	}else{
		$end_date = date('m/d/Y');
	}
	
	$counter=1;
	$dom = new DOMDocument;
	$dom->loadXML($invoices);
	$lis = $dom->getElementsByTagName('li');
	foreach ($lis as $li) {
		$nodes = $li->getElementsByTagName('a');
		$name = $li->nodeValue;
		$explode_name = explode(" ",trim($name));
		$file_name = $explode_name[0];
		//echo "<br><br>file name is: ".$file_name;
		
		$link = $nodes->item(0)->getAttribute('href');
		$parseurl = parse_str($link,$result);
		$adx = $result['adx'];
		
		$download_link = "https://secure.bankofamerica.com/myaccounts/details/deposit/download-transactions.go?adx=$adx&downloadTransactionType=customRange&searchBean.timeFrameStartDate=$date&searchBean.timeFrameEndDate=$end_date&formatType=csv";
		
		echo $counter.") ".$file_name." <a href='$download_link'>Download</a><br><br>";
		
		$counter++;
	}
	
}else{
?>


<script type="text/javascript" src="datepicker/formden.js"></script>
<link rel="stylesheet" href="datepicker/bootstrap-iso.css" />
 
<div class="bootstrap-iso">
 <div class="container-fluid">
  <div class="row">
   <div class="col-md-6 col-sm-6 col-xs-12">
    <form action="index.php" class="form-horizontal" method="post">
     
     <div class="form-group ">
      <label class="control-label col-sm-2 requiredField" for="date">Start Date</label>
      <div class="col-sm-10">
       <div class="input-group">
        <input class="form-control" id="date" name="date" placeholder="MM/DD/YYYY" type="text"/>
       </div>
      </div>
     </div>
     
     <div class="form-group ">
      <label class="control-label col-sm-2 requiredField" for="date2">End Date</label>
      <div class="col-sm-10">
       <div class="input-group">
        <input class="form-control" id="end_date" name="end_date" placeholder="MM/DD/YYYY" type="text"/>
       </div>
      </div>
     </div>
     
     <div class="form-group ">
      <label class="control-label col-sm-2 requiredField" for="date">Invoices List</label>
      <div class="col-sm-10">
       <div class="input-group">
        <textarea name="invoices_list" rows="15" cols="150"></textarea>
       </div>
      </div>
     </div>
     
     
     <div class="form-group">
      <div class="col-sm-10 col-sm-offset-2">
       <input type="submit" value="Generate Links">
      </div>
     </div>
     
    </form>
   </div>
  </div>
 </div>
</div>

<script type="text/javascript" src="datepicker/jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="datepicker/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="datepicker/bootstrap-datepicker3.css"/>

<script>
	$(document).ready(function(){
		var date_input=$('input[name="date"]');
		var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
		date_input.datepicker({
			format: 'mm/dd/yyyy',
			container: container,
			todayHighlight: true,
			autoclose: true,
		});
		
		var date_input=$('input[name="end_date"]');
		var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
		date_input.datepicker({
			format: 'mm/dd/yyyy',
			container: container,
			todayHighlight: true,
			autoclose: true,
		});
	})
</script>

<?php } ?>