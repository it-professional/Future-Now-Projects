<?php if(isset($_POST['invoices_list']) && !empty($_POST['invoices_list'])){
	$invoices = $_POST['invoices_list'];
	
	$file_names = array();
	//$lis_count = 0;
	
	$dom = new DOMDocument;
	$dom->loadXML($invoices);
	$lis = $dom->getElementsByTagName('li');
	foreach ($lis as $li) {
		$nodes = $li->getElementsByTagName('a');
		$name = $li->nodeValue;
		$explode_name = explode(" ",trim($name));
		$file_name = $explode_name[0];
		$file_names[] = trim($file_name);
	}
	
	echo "Total Bank Invoices: <strong>".count($file_names)."</strong>";
	
	$all_files = glob('invoices/*',GLOB_NOSORT);;
	$counter = 0; $rename_files_count = 0;
	foreach($all_files as $find_file) {
		$name = pathinfo($find_file, PATHINFO_FILENAME);
		
		if(isset($file_names[$counter])){
			rename("invoices/".$name.".csv","invoices/".$file_names[$counter].".csv");
			$rename_files_count++;
		}
		$counter++;
	}
	
	echo "<br><br>Renamed Invoices: <strong>".$rename_files_count."</strong>";
	
	echo "<br><br>Total Invoices in Directory: <strong>".count($all_files)."</strong>";
	
}else{
?>

<div class="bootstrap-iso">
 <div class="container-fluid">
  <div class="row">
   <div class="col-md-6 col-sm-6 col-xs-12">
    <form action="rename.php" class="form-horizontal" method="post">
     
     <div class="form-group ">
      <label class="control-label col-sm-2 requiredField" for="date">Invoices List</label>
      <div class="col-sm-10">
       <div class="input-group">
        <textarea name="invoices_list" rows="15" cols="150"></textarea>
       </div>
      </div>
     </div>
     
     <div class="form-group">
      <div class="col-sm-10 col-sm-offset-2">
       <input type="submit" value="Rename Files">
      </div>
     </div>
     
    </form>
   </div>
  </div>
 </div>
</div>
<?php } ?>